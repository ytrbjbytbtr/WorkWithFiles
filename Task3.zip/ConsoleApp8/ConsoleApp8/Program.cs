﻿using System;
using System.IO;

namespace ConsoleApp8
{
    class Program
    {
        static void Main(string[] args)
        {
            float folderSize = 0.0f;
            FileInfo[] files = Directory.GetFiles(folder, "*", SearchOptions.AllDirectories);
            foreach (FileInfo file in files) folderSize += file.Length;
            TimeSpan span = TimeSpan.FromMinutes(30);
            string directoria = @"C:\Users\79216\Desktop\";
            Directory.Delete(directoria, true); //true - если директория не пуста удаляем все ее содержимое
            Directory.CreateDirectory(directoria);

        }
    }
}
